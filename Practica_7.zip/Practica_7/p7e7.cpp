#include <iostream>
#include <array>
using namespace std;

const int MAX_CARGOS = 15;
const int MAX_PARTIDOS = 10;